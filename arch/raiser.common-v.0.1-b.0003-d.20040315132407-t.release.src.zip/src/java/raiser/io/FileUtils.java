/*
 * Created on Jan 16, 2004
 */
package raiser.io;

import java.io.*;

/**
 * @author raiser
 */
public class FileUtils
{
    /** File separator ("/" on Unix).*/
    public static String getFileSeparator()
    {
        return System.getProperty("file.separator");
    }
    /** Path separator (":" on Unix).*/
    public static String getPathSeparator()
    {
        return System.getProperty("path.separator");
    }
    /** Line separator ("\n" on Unix).*/
    public static String getLineSeparator()
    {
        return System.getProperty("line.separator");
    }

    /**
     * @param path
     * @return
     */
    public static String getPath(String path)
    {
        return path.endsWith(getFileSeparator())
            ? path
            : path + getFileSeparator();
    }
    public static void copy(String sourceFileName, String destinationFileName)
        throws IOException
    {
        Reader reader = new BufferedReader(new FileReader(sourceFileName));
        Writer writer = new BufferedWriter(new FileWriter(destinationFileName));
        char str[] = new char[1024];
        int nb;
        while ((nb = reader.read(str)) >= 0)
        {
            writer.write(str, 0, nb);
        }
        writer.close();
        reader.close();
    }
    /**
     * On some JVMs there is a bug in delete method.
     */
    public static boolean delete(File file)
        throws InterruptedException, IOException
    {
        return delete(file, 1000, 10);
    }
    /**
     * On some JVMs there is a bug in delete method.
     */
    public static boolean delete(String fileName)
        throws InterruptedException, IOException
    {
        return delete(new File(fileName), 1000, 10);
    }
    /**
     * On some JVMs there is a bug in delete method.
     */
    /**
     * On some JVMs there is a bug in delete method.
     */
    static boolean delete(File file, int timeout, int tries) throws IOException
    {
        try
        {
            if (!file.exists())
            {
                throw new IOException(
                    "File "
                        + file.getAbsolutePath()
                        + " doesn't exist. Can't delete non existent files.");
            }
            if (file.delete())
            {
                return true;
            }
            System.err.println(
                "Directly delete of existing file "
                    + file.getAbsolutePath()
                    + " failed. You should consider closing all streams connected on this file.");
            boolean result = false;
            int pause = timeout / tries;
            for (int i = 0;(i < tries) && (!(result = file.delete())); i++)
            {
                System.gc();
                Thread.sleep(pause);
            }
            System.err.println(
                "After some hacks the file "
                    + file.getAbsolutePath()
                    + (result
                        ? " was deleted."
                        : " was NOT deleted. I tried "
                            + tries
                            + " times x "
                            + 
                            + pause
                            + " miliseconds."));
            return result;
        }
        catch (InterruptedException e)
        {
            throw new IOException("The process of deleting file "+file.getAbsolutePath()+" was interrupted.");
        }
    }
}
