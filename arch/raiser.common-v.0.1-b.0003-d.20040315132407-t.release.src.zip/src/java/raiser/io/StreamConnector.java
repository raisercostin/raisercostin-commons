/*
 ******************************************************************************
 *    $Logfile: $
 *   $Revision: 1.1.1.1 $
 *     $Author: raisercostin $
 *       $Date: 2004/03/12 19:33:07 $
 * $NoKeywords: $
 *****************************************************************************/
package raiser.io;

import java.io.*;
import java.io.InputStream;

/**
 * @author: Costin Emilian GRIGORE
 */
public class StreamConnector
{
    /**
     * Reads all data available from source and writes to destination.
     * @param source
     * @param destination
     */
    public void connect(InputStream source, OutputStream destination)
    {
        
    }
    /**
     * Reads all data available from source and writes to destination.
     * @param source
     * @param destination
     */
    public void connect(OutputStream source, InputStream destination)
    {
        
    }
}
