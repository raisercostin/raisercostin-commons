/*
 ******************************************************************************
 *    $Logfile: $
 *   $Revision: 1.2 $
 *     $Author: raisercostin $
 *       $Date: 2004/03/18 18:27:45 $
 * $NoKeywords: $
 *****************************************************************************/
package raiser.net.ftp;

/**
 * @author: Costin Emilian GRIGORE
 */
public class FtpClientFactory
{
    public static FtpClient createFtpClient()
    {
        return createApacheFtpClient();
    }
    public static FtpClient createSunFtpClient()
    {
        return new SunFtpClient();
    }
    public static FtpClient createApacheFtpClient()
    {
        return new ApacheFtpClient();
    }
    public static FtpClient createEnterpriseDistributedTechnologiesFtpClient()
    {
        return new EnterpriseDistributedTechnologiesFtpClient();
    }
}
