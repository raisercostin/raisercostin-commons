/*
 ******************************************************************************
 *    $Logfile: $
 *   $Revision: 1.1.1.1 $
 *     $Author: raisercostin $
 *       $Date: 2004/03/12 19:33:10 $
 * $NoKeywords: $
 *****************************************************************************/
package raiser.net.ftp;

import java.io.IOException;

/**
 * @author: Costin Emilian GRIGORE
 */
public class FtpProtocolException extends IOException
{
    
    public FtpProtocolException()
    {
        super();
    }
    public FtpProtocolException(String message)
    {
        super(message);
    }
    public FtpProtocolException(String message, Throwable cause) {
        this(message);
        initCause(cause);
    }
    public FtpProtocolException(Throwable cause) {
        this();
        initCause(cause);
    }
}
