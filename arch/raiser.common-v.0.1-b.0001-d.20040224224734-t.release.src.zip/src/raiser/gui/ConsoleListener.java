/*
 * Created on Nov 30, 2003
 */
package raiser.gui;


/**
 * @author raiser
 */
public interface ConsoleListener
{
    void setConsole(Console console);
    void fireClose();
}
