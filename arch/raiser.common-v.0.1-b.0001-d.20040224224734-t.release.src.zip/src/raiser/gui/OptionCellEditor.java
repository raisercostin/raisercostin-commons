/*
 * Created on Jan 14, 2004
 */
package raiser.gui;

import java.awt.Component;
import java.awt.event.*;
import java.util.EventObject;

import javax.swing.*;

/**
 * @author raiser
 */
public class OptionCellEditor extends DefaultCellEditor implements CellEditor
{
    OptionCell currentValue = null;
    public OptionCellEditor(final JComboBox comboBox)
    {
        //Unfortunately, the constructor expects a check box, combo box, or text field.
        super(new JCheckBox());
        editorComponent = comboBox;
        //This is usually 1 or 2.
        setClickCountToStart(1);
        comboBox.putClientProperty("JComboBox.isTableCellEditor", Boolean.TRUE);
        delegate = new EditorDelegate()
        {
            public void setValue(Object value)
            {
                comboBox.setSelectedItem(value);
            }

            public Object getCellEditorValue()
            {
                return comboBox.getSelectedItem();
            }

            public boolean shouldSelectCell(EventObject anEvent)
            {
                if (anEvent instanceof MouseEvent)
                {
                    MouseEvent e = (MouseEvent) anEvent;
                    return e.getID() != MouseEvent.MOUSE_DRAGGED;
                }
                return true;
            }
            public boolean stopCellEditing()
            {
                if (comboBox.isEditable())
                {
                    // Commit edited value.
                    comboBox.actionPerformed(
                        new ActionEvent(OptionCellEditor.this, 0, ""));
                }
                return super.stopCellEditing();
            }
        };
        comboBox.addActionListener(delegate);
    }

    protected void fireEditingStopped()
    {
        int fire = getJComboBox().getSelectedIndex();
        System.out.println(
            "fire="
                + fire
                + " value=<"
                + getJComboBox().getSelectedItem()
                + ">");
        if (fire != -1)
        {
            currentValue.setSelected(fire);
        }
        if (fire == -1)
        {
            if ((getJComboBox().getSelectedItem() != null)
                && (!getJComboBox().getSelectedItem().equals("")))
            {
                currentValue.addAndSelect(getJComboBox().getSelectedItem());
            }
        }
        super.fireEditingStopped();
    }

    public Object getCellEditorValue()
    {
        return currentValue;
    }

    public Component getTableCellEditorComponent(
        JTable table,
        Object value,
        boolean isSelected,
        int row,
        int column)
    {
        currentValue = (OptionCell) value;
        DynamicComboBoxModel model =
            (DynamicComboBoxModel) getJComboBox().getModel();
        model.removeAllElements();
        model.insertElementsAt(currentValue.getObjects(), 0);
        getJComboBox().setEditable(currentValue.isEditable());
        System.out.println("selected=<" + currentValue.getSelected() + ">");
        getJComboBox().setSelectedItem(currentValue.getSelected());
        //getJComboBox().setSelectedIndex(currentValue.getSelected());
        return editorComponent;
    }

    private JComboBox getJComboBox()
    {
        return ((JComboBox) editorComponent);
    }
}
