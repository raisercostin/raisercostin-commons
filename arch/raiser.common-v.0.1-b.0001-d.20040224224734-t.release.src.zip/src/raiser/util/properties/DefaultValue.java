/*
 ******************************************************************************
 *    $Logfile: $
 *   $Revision: 1.2 $
 *     $Author: raisercostin $
 *       $Date: 2004/03/08 19:21:07 $
 * $NoKeywords: $
 *****************************************************************************/
package raiser.util.properties;

/**
 * @author: Costin Emilian GRIGORE
 */
public interface DefaultValue
{

    /**
     * @param val
     * @return
     */
    Object getDefaultValue(Object val);

}
