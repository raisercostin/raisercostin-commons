/*
 ******************************************************************************
 *    $Logfile: $
 *   $Revision: 1.2 $
 *     $Author: raisercostin $
 *       $Date: 2004/03/08 19:21:55 $
 * $NoKeywords: $
 *****************************************************************************/
package raiser.util.properties;

/**
 * @author: Costin Emilian GRIGORE
 */
public interface Descriptable
{
    String getDescription(Object object);
}
