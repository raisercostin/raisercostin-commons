/*
 ******************************************************************************
 *    $Logfile: $
 *   $Revision: 1.2 $
 *     $Author: raisercostin $
 *       $Date: 2004/03/08 19:23:43 $
 * $NoKeywords: $
 *****************************************************************************/
package raiser.util;


/**
 * @author: Costin Emilian GRIGORE
 */
public class ArraysUtil
{
    public static byte[] toByteArray(Object[] array)
    {
        byte[] result = new byte[array.length];
        for (int i = 0; i < result.length; i++)
        {
            result[i] = ((Number)array[i]).byteValue();
        }
        return result;
    }
}
