/*
 * Created on Jul 18, 2003
 */
package raiser.io;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * @author raiser
 */
public class CommentReader
{
    /**
     * @param reader
     * @return
     * @throws IOException
     */
    public static String readLine(BufferedReader reader,String commentBegin) throws IOException
    {
        String result;
        while( ( (result = reader.readLine()) != null ) && (result.startsWith(commentBegin)));
        return result;        
    }
}
