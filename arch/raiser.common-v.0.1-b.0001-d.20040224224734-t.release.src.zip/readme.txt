generare descriere proiect in html din xml
checklist before add to cvs