package raiser.gui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Console
{
    private boolean resizable;
    private JFrame frame;
    private int height;
    private int width;
    private String title;
    ConsoleListener consoleListener; 
    public Console(
        String title,
        int width,
        int height,
        boolean resize)
    {
        this.title = title;
        this.width = width;
        this.height = height;
        this.resizable = resize;
    }
    private boolean running;
    private Object synchronizer = new byte[0];
    // Create a title string from the class name:
    public static String title(Object o)
    {
        String t = o.getClass().toString();
        // Remove the word "class":
        if (t.indexOf("class") != -1)
            t = t.substring(6);
        return t;
    }
    public static void setupClosing(JFrame frame)
    {
        // The JDK 1.2 Solution as an
        // anonymous inner class:
        frame.addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
        // The improved solution in JDK 1.3:
        // frame.setDefaultCloseOperation(
        // EXIT_ON_CLOSE);
    }
    public static void run(
        JFrame frame,
        int left,
        int top,
        int width,
        int height)
    {
        setupClosing(frame);
        frame.setLocation(left, top);
        frame.setSize(width, height);
        frame.setVisible(true);
    }
    public static void run(
        JApplet applet,
        int left,
        int top,
        int width,
        int height)
    {
        JFrame frame = new JFrame(title(applet));
        setupClosing(frame);
        frame.getContentPane().add(applet);
        frame.setLocation(left, top);
        frame.setSize(width, height);
        applet.init();
        applet.start();
        frame.setVisible(true);
    }
    public static void run(
        JPanel panel,
        int left,
        int top,
        int width,
        int height)
    {
        JFrame frame = new JFrame(title(panel));
        setupClosing(frame);
        frame.getContentPane().add(panel);
        frame.setLocation(left, top);
        frame.setSize(width, height);
        frame.setVisible(true);
    }
    public Console runBlocked(JPanel panel)
    {
        setRunning(true);
        frame = new JFrame();
        setupClosing();
        if (panel instanceof Menuable)
        {
            frame.setJMenuBar(((Menuable) panel).getJMenuBar());
        }
        if (panel instanceof ConsoleListener)
        {
            ((ConsoleListener) panel).setConsole(this);
            consoleListener = (ConsoleListener) panel;
        }
        frame.getContentPane().add(new MyPanel(panel));
        frame.setLocation(computeCentered(width, height));
        frame.setTitle(title);
        frame.setSize(width, height);
        frame.setVisible(true);
        frame.setResizable(resizable);
        return this;
    }
    class MyPanel extends JPanel
    {
        private Console console;
        MyPanel(JPanel panel)
        {
            setLayout(new BorderLayout()); 
            add(panel,BorderLayout.CENTER);
            this.console= Console.this;
        }
        public void invalidate()
        {
            super.invalidate();
            pack();
        }
        public Frame getFrame()
        {
            return console.frame;
        }
        public Console getConsole()
        {
            return console;
        }
    }
    private static Point computeCentered(int width, int height)
    {
        Point result = new Point();
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        result.x = (int) ((toolkit.getScreenSize().getWidth() - width) / 2);
        result.y = (int) ((toolkit.getScreenSize().getHeight() - height) / 2);
        return result;
    }
    public void setupClosing()
    {
        // The JDK 1.2 Solution as an
        // anonymous inner class:
        frame.addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                exit();
            }
        });
        // The improved solution in JDK 1.3:
        //frame.setDefaultCloseOperation(
        //EXIT_ON_CLOSE);
    }
    public void join() throws InterruptedException
    {
        synchronized (synchronizer)
        {
            while (isRunning())
            {
                synchronizer.wait();
            }
        }
    }
    private boolean isRunning()
    {
        synchronized (synchronizer)
        {
            return running;
        }
    }
    public void setRunning(boolean running)
    {
        synchronized (synchronizer)
        {
            this.running = running;
        }
    }
    public void exit()
    {
        if(consoleListener != null)
        {
            consoleListener.fireClose();
        }
        frame.dispose();
        synchronized (synchronizer)
        {
            setRunning(false);
            synchronizer.notifyAll();
        }
    }
    public void pack()
    {
        if(!frame.isResizable())
        {
            frame.pack();
        }
    }
    public static void makeCentred(JDialog dialog)
    {
        dialog.setLocation(
            computeCentered(dialog.getWidth(), dialog.getHeight()));
    }
    public Frame getFrame()
    {
        return frame;
    }
    public static Frame getFrame(JPanel panel)
    {
        return ((MyPanel)panel.getParent()).getFrame();
    }
    public static Console getConsole(JPanel panel)
    {
        return ((MyPanel)panel.getParent()).getConsole();
    }

}