/*
 * Created on Nov 30, 2003
 */
package raiser.gui;

import javax.swing.JMenuBar;

/**
 * @author raiser
 */
public interface Menuable
{
    public JMenuBar getJMenuBar();
}
