/*
 * Created on Jan 14, 2004
 */
package raiser.gui;

import javax.swing.event.*;

/**
 * @author raiser
 */
public class OptionCell
{
    private EventListenerList listenerList;
    private ChangeEvent changeEvent;
    private Object editedValue;
    private boolean editable;
    private Object objects[];
    private int selected;
    public OptionCell(Object objects[], int selected, boolean acceptNewValues)
    {
        this.objects = objects;
        this.selected = selected;
        this.editedValue = null;
        this.editable = acceptNewValues;
        listenerList = new EventListenerList();
    }
    public OptionCell(Object objects[])
    {
        this.objects = objects;
        this.selected = 0;
        this.editedValue = null;
        this.editable = false;
        listenerList = new EventListenerList();
    }
    public void setSelected(int index)
    {
        if (index < 0)
            throw new IndexOutOfBoundsException("Bad index=" + index + ".");
        if (index >= getObjects().length)
            throw new IndexOutOfBoundsException("Bad index=" + index + ".");
        if(this.selected == index)
            return;
        this.selected = index;
        this.editedValue = null;
        fireChangeListener();
    }
    public int getSelectedIndex()
    {
        return selected;
    }
    public void setEditable(boolean acceptNewValues)
    {
        this.editable = acceptNewValues;
        editedValue = null;
    }

    public boolean isEditable()
    {
        return editable;
    }

    public void setObjects(Object[] objects)
    {
        this.objects = objects;
    }

    public Object[] getObjects()
    {
        return objects;
    }
    public void addAndSelect(Object value)
    {
        if (isEditable())
        {
            if(value==null)
            {
                return;
            }
            if(value.equals(editedValue))
            {
                return;
            }
            this.editedValue = value;
            this.selected = -1;
            fireChangeListener();
        }
    }
    public Object getSelected()
    {
        if ((isEditable()) && (editedValue != null))
            return editedValue;
        return objects[selected];
    }
    public String toString()
    {
        if ((isEditable()) && (editedValue != null))
        {
            return editedValue.toString();
        }
        if ((getObjects() == null) || (getObjects().length == 0))
            return "";
        if (getObjects()[selected] == null)
            return "";
        return getObjects()[selected].toString();
    }
    public void addChangeListener(ChangeListener changeListener)
    {
        listenerList.add(ChangeListener.class, changeListener);
    }
    public void removeFooListener(ChangeListener changeListener)
    {
        listenerList.remove(ChangeListener.class, changeListener);
    }
    protected void fireChangeListener()
    {
        // Guaranteed to return a non-null array
        Object[] listeners = listenerList.getListenerList();
        // Process the listeners last to first, notifying
        // those that are interested in this event
        for (int i = listeners.length - 2; i >= 0; i -= 2)
        {
            if (listeners[i] == ChangeListener.class)
            {
                ((ChangeListener) listeners[i + 1]).stateChanged(getChangeEvent());
            }
        }
    }
    private ChangeEvent getChangeEvent()
    {
        // Lazily create the event:
        if (changeEvent == null)
            changeEvent = new ChangeEvent(this);
        return changeEvent;
    }
}
