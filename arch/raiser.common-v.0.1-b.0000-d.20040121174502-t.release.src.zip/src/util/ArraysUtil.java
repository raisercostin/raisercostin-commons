/*
 ******************************************************************************
 *    $Logfile: $
 *   $Revision: $
 *     $Author: $
 *       $Date: $
 * $NoKeywords: $
 *****************************************************************************/
package util;


/**
 * @author: Costin Emilian GRIGORE
 */
public class ArraysUtil
{
    public static byte[] toByteArray(Object[] array)
    {
        byte[] result = new byte[array.length];
        for (int i = 0; i < result.length; i++)
        {
            result[i] = ((Number)array[i]).byteValue();
        }
        return result;
    }
}
