/*
 ******************************************************************************
 *    $Logfile: $
 *   $Revision: $
 *     $Author: $
 *       $Date: $
 * $NoKeywords: $
 *****************************************************************************/
package util.properties;

/**
 * @author: Costin Emilian GRIGORE
 */
public interface Descriptable
{
    String getDescription(Object object);
}
