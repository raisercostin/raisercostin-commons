/*
 * Created on Nov 13, 2003
 */
package com.rp.util;

/**
 * @author raiser
 */
public class Formatter
{
    public static String toHexString(int number, int digits)
    {
        boolean possitive = true;
        if(number < 0)
        {
            number = -number;
            possitive = false;
        }
        StringBuffer result = new StringBuffer(Integer.toHexString(number));
        if(result.length() < digits)
        {
            for(int i = digits - result.length() ; i > 0 ; i--)
            {
                result.insert(0,'0');
            }
        }
        if(!possitive)
        {
            result.insert(0,'-');
        }
        return result.toString();
    }
}
