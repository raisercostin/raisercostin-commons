/*
 * Created on Nov 7, 2003
 */
package com.rp.gui;

import java.awt.Cursor;
import java.awt.event.*;

import javax.swing.*;

/**
 * @author raiser
 */
public class JLinkButton extends JLabel
{

    private String plainText;
    public JLinkButton()
    {
        super();
        init();
    }

    /**
     * @param text
     */
    public JLinkButton(String text)
    {
        super(text);
        init();
    }

    /**
     * @param text
     * @param horizontalAlignment
     */
    public JLinkButton(String text, int horizontalAlignment)
    {
        super(text, horizontalAlignment);
        init();
    }

    /**
     * @param image
     */
    public JLinkButton(Icon image)
    {
        super(image);
        init();
    }

    /**
     * @param image
     * @param horizontalAlignment
     */
    public JLinkButton(Icon image, int horizontalAlignment)
    {
        super(image, horizontalAlignment);
        init();
    }

    /**
     * @param text
     * @param icon
     * @param horizontalAlignment
     */
    public JLinkButton(String text, Icon icon, int horizontalAlignment)
    {
        super(text, icon, horizontalAlignment);
        init();
    }
    public void setText(String text)
    {
        plainText = text;
        refreshText();
    }
    public void setEnabled(boolean enabled)
    {
        super.setEnabled(enabled);
        refreshText();
    }
    
    private void refreshText()
    {
        if(isEnabled())
        {
            super.setText("<html><U>"+plainText+"</U></html>");            
        }
        else
        {
            super.setText("<html>"+plainText+"</html>");
        }
    }

    void init()
    {
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        plainText = getText();
        refreshText();
    }

    /**
     * @param devicesAction
     */
    public void addActionListener(ActionListener devicesAction)
    {
        addMouseListener(new LinkMouseListener(devicesAction));
    }
    class LinkMouseListener extends MouseAdapter 
    {
        private ActionListener devicesAction;
        public LinkMouseListener(ActionListener devicesAction)
        {
            this.devicesAction = devicesAction;
        }
        public void mouseClicked(MouseEvent e)
        {
            devicesAction.actionPerformed(null);
        }
    }
}
