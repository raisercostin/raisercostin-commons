/**
 * @project infocontroll
 * @author raiser
 * @creation time Oct 1, 2003.2:45:52 PM
 */
package com.rp.gui;

import javax.swing.JMenuBar;

/**
 * An application has a menu.
 */
public interface Menuable
{
    JMenuBar getMenuBar();
}
