package com.rp.gui;

import java.awt.*;
import java.util.Hashtable;

// Referenced classes of package edu.umn.genomics.layout:
//            Extents

public class RelativeLayout implements LayoutManager2
{

    public RelativeLayout()
    {
        compTable = new Hashtable();
    }

    public void setConstraints(Component comp, RelativeConstraints extents)
    {
        compTable.put(comp, extents);
    }

    public void addLayoutComponent(String s, Component component)
    {
    }

    public void removeLayoutComponent(Component comp)
    {
        compTable.remove(comp);
    }

    public Dimension preferredLayoutSize(Container parent)
    {
        return getLayoutSize(parent, true);
    }

    public Dimension minimumLayoutSize(Container parent)
    {
        return getLayoutSize(parent, false);
    }

    protected Dimension getLayoutSize(Container parent, boolean isPreferred)
    {
        int w = 0;
        int h = 0;
        Component ca[] = parent.getComponents();
        for (int i = 0; i < ca.length; i++)
        {
            RelativeConstraints e = (RelativeConstraints) compTable.get(ca[i]);
            if (e == null)
                continue;
            Dimension cd;
            if (isPreferred)
                cd = ca[i].getPreferredSize();
            else
                cd = ca[i].getMinimumSize();
            if (cd == null)
                continue;
            if (e.getWidth() != 0.0D)
            {
                int cw = (int) (cd.width / e.getWidth());
                if (w < cw)
                    w = cw;
            }
            if (e.getHeight() == 0.0D)
                continue;
            int ch = (int) (cd.height / e.getHeight());
            if (h < ch)
                h = ch;
        }

        return new Dimension(w, h);
    }

    public void layoutContainer(Container parent)
    {
        Object obj = parent.getTreeLock();
        synchronized (obj)
        {
            Insets insets;
            int ncomponents;
            insets = parent.getInsets();
            ncomponents = parent.getComponentCount();
            if (ncomponents != 0)
            {
                Dimension size = parent.getSize();
                int totalW = size.width - (insets.left + insets.right);
                int totalH = size.height - (insets.top + insets.bottom);
                for (int i = 0; i < ncomponents; i++)
                {
                    Component c = parent.getComponent(i);
                    RelativeConstraints e = (RelativeConstraints) compTable.get(c);
                    Dimension d = c.getPreferredSize();
                    if (e != null)
                    {
                        int x =
                            insets.left + (int) (totalW * e.getX());
                        int y = insets.top + (int) (totalH * e.getY());
                        int w = (int)d.getWidth();
                        if( e.widthIsSetted() )
                            w = (int) (totalW * e.getWidth());
                        int h = (int)d.getHeight();
                        if(e.heightIsSetted())
                            h = (int) (totalH * e.getHeight());
                        c.setBounds(x, y, w, h);
                    }
                }
            }
        }
    }

    public void addLayoutComponent(Component comp, Object constraints)
    {
        if (constraints instanceof RelativeConstraints)
            setConstraints(comp, (RelativeConstraints) constraints);
        else if (constraints != null)
            throw new IllegalArgumentException("cannot add to layout: constraint must be Extents");
    }

    public Dimension maximumLayoutSize(Container target)
    {
        return new Dimension(0x7fffffff, 0x7fffffff);
    }

    public float getLayoutAlignmentX(Container target)
    {
        return 0.5F;
    }

    public float getLayoutAlignmentY(Container target)
    {
        return 0.5F;
    }

    public void invalidateLayout(Container container)
    {
    }

    Hashtable compTable;
}
