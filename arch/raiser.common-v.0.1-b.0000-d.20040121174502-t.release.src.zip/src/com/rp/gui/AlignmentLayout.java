package com.rp.gui;

import java.awt.*;
import java.util.Hashtable;

// Referenced classes of package edu.umn.genomics.layout:
//            Extents

public class AlignmentLayout implements LayoutManager2
{

    public static final AlignmentConstraints CENTER = new AlignmentConstraints(AlignmentConstraints.CENTER,AlignmentConstraints.CENTER);
    public static final AlignmentConstraints NORTH_EST = new AlignmentConstraints(AlignmentConstraints.RIGHT,AlignmentConstraints.TOP);
    public static final AlignmentConstraints EST = new AlignmentConstraints(AlignmentConstraints.RIGHT,AlignmentConstraints.CENTER);
    public static final AlignmentConstraints SOUTH = new AlignmentConstraints(AlignmentConstraints.CENTER,AlignmentConstraints.BOTTOM);

    public AlignmentLayout()
    {
        compTable = new Hashtable();
    }

    public void setConstraints(Component comp, AlignmentConstraints extents)
    {
        compTable.put(comp, extents);
    }

    /**
	 * @deprecated
	 */
    public void addLayoutComponent(String s, Component component)
    {
        throw new Error("Unimplemented method.");
    }

    public void removeLayoutComponent(Component comp)
    {
        compTable.remove(comp);
    }

    public Dimension preferredLayoutSize(Container parent)
    {
        return getLayoutSize(parent, true);
    }

    public Dimension minimumLayoutSize(Container parent)
    {
        return getLayoutSize(parent, false);
    }

    protected Dimension getLayoutSize(Container parent, boolean isPreferred)
    {
        return parent.getSize();
    }

    public void layoutContainer(Container parent)
    {
        Object obj = parent.getTreeLock();
        synchronized (obj)
        {
            Insets insets;
            int ncomponents;
            insets = parent.getInsets();
            ncomponents = parent.getComponentCount();
            if (ncomponents != 0)
            {
                Dimension size = parent.getPreferredSize();
                int totalW = size.width - (insets.left + insets.right);
                int totalH = size.height - (insets.top + insets.bottom);
                for (int i = 0; i < ncomponents; i++)
                {
                    Component c = parent.getComponent(i);
                    AlignmentConstraints e =
                        (AlignmentConstraints) compTable.get(c);
                    Dimension d = c.getPreferredSize();
                    if (e != null)
                    {
                        int w = (int) d.getWidth();
                        int h = (int) d.getHeight();
                        int x =
                            (int) (insets.left + e.getAlignmentX() * (totalW - w));
                        int y = (int) (insets.top + e.getAlignmentY() * (totalH-h));
                        c.setBounds(x, y, w, h);
                    }
                }
            }
        }
    }

    public void addLayoutComponent(Component comp, Object constraints)
    {
        if (constraints instanceof AlignmentConstraints)
            setConstraints(comp, (AlignmentConstraints) constraints);
        else if (constraints != null)
            throw new IllegalArgumentException("cannot add to layout: constraint must be Extents");
    }

    public Dimension maximumLayoutSize(Container target)
    {
        return new Dimension(0x7fffffff, 0x7fffffff);
    }

    public float getLayoutAlignmentX(Container target)
    {
        return 0.5F;
    }

    public float getLayoutAlignmentY(Container target)
    {
        return 0.5F;
    }

    public void invalidateLayout(Container container)
    {
    }

    Hashtable compTable;
}
