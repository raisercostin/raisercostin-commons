/**
 * @project common
 * @author raiser
 * @creation time Sep 24, 2003.6:39:10 PM
 */
package com.rp.gui;

import java.awt.BorderLayout;

import javax.swing.*;

/**
 * Any component with a label.
 */
public class JLabeledComponent extends JPanel
{

    private String label = "";
    private JComponent component = null;

    /**
     * @return
     */
    public JComponent getComponent()
    {
        return component;
    }

    /**
     * @param component
     */
    public void setComponent(JComponent component)
    {
        this.component = component;
    }

    /**
     * 
     */
    public JLabeledComponent(String label, JComponent component)
    {
        this.label = label;
        this.component = component;
        setLayout(new BorderLayout());
        add(new JLabel(label),BorderLayout.WEST);
        add(component,BorderLayout.CENTER);
    }

    public void setLabel(String label)
    {
        this.label = label; 
    }
    public String getLabel()
    {
        return label;
    }
}
