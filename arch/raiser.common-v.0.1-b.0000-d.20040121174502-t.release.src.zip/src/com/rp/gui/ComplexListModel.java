/*
 * Created on Oct 28, 2003
 */
package com.rp.gui;

import java.util.Vector;

import javax.swing.DefaultComboBoxModel;

/**
 * @author raiser
 */
public class ComplexListModel extends DefaultComboBoxModel
{
    
    public void fireContentsChanged(Object source, int index0, int index1)
    {
        super.fireContentsChanged(source, index0, index1);
    }
    public ComplexListModel()
    {
        super();
    }
    public ComplexListModel(Object[] items)
    {
        super(items);
    }
    public ComplexListModel(Vector v)
    {
        super(v);
    }

}
