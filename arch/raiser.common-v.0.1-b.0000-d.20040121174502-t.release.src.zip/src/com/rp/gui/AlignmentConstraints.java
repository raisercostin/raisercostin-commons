package com.rp.gui;

public class AlignmentConstraints
{

    public static final float CENTER = 0.5f;
    public static final float LEFT = 0.0f;
    public static final float RIGHT = 1.0f;
    public static final float TOP = 0.0f;
    public static final float BOTTOM = 1.0f;

    private float alignmentX;
    private float alignmentY;

    public AlignmentConstraints()
    {
        this(0.5f,0.5f);
    }

    public AlignmentConstraints(
        float alignmentX,
        float alignmentY)
    {
        this.alignmentX = alignmentX;
        this.alignmentY = alignmentY;
    }

    public float getAlignmentX()
    {
        return alignmentX;
    }

    public float getAlignmentY()
    {
        return alignmentY;
    }
    public String toString()
    {
        StringBuffer result = new StringBuffer();
        result.append("AlignmentConstraints[");
        result.append(alignmentX);
        result.append(",");
        result.append(alignmentY);
        result.append("]");
        return result.toString();
    }
}
