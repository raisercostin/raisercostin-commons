package com.rp.gui;

public class RelativeConstraints
{

    public RelativeConstraints()
    {
        this(0.0D, 0.0D, 1.0D, 1.0D,true,true);
    }

    public RelativeConstraints(
        double fromX,
        double fromY,
        double toX,
        double toY,
        boolean widthIsSetted,
        boolean heightIsSetted)
    {
        this.fromX = fromX;
        this.fromY = fromY;
        this.toX = toX;
        this.toY = toY;
        this.widthIsSetted = widthIsSetted;
        this.heightIsSetted = heightIsSetted;
    }

    public double getWidth()
    {
        return toX - fromX;
    }

    public double getHeight()
    {
        return toY - fromY;
    }

    public double getX()
    {
        return fromX;
    }

    public double getY()
    {
        return fromY;
    }

    public String toString()
    {
        StringBuffer result = new StringBuffer();
        result.append("RelativeConstraints[");
        result.append(fromX);
        result.append(",");
        result.append(fromY);
        result.append(",");
        result.append(toX);
        result.append(",");
        result.append(toY);
        result.append(",");
        result.append(widthIsSetted);
        result.append(",");
        result.append(heightIsSetted);
        result.append("]");
        return result.toString();
    }
    double fromX;
    double fromY;
    double toX;
    double toY;
    boolean widthIsSetted;
    boolean heightIsSetted;
    
    public boolean widthIsSetted()
    {
        return widthIsSetted;
    }
    public boolean heightIsSetted()
    {
        return heightIsSetted;
    }
}
