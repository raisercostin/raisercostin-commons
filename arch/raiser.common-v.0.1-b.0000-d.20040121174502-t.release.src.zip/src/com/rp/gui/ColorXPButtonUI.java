/*
 * Created on Nov 24, 2003
 */
package com.rp.gui;

import java.awt.*;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.*;

public class ColorXPButtonUI extends BasicButtonUI
{
    // Created for compatibility with system UI.
    private final static ColorXPButtonUI m_buttonUI = new ColorXPButtonUI();

    private final int ARC_HEIGHT = 6;
    private final int ARC_WIDTH = 6;

    AbstractButton m_button;

    public ColorXPButtonUI()
    {
    }

    // ********************************
    // Create PLAF
    // ********************************
    public static ComponentUI createUI(JComponent c)
    {
        return m_buttonUI;
    }

    public void paint(Graphics g, JComponent c)
    {
        m_button = (AbstractButton) c;
        paintBackground(g);
        paintBorder(g);
        paintText(g);
    }

    protected void paintBackground(Graphics g)
    {
        Rectangle buttonRect = m_button.getBounds();

        // Clear any attempts from the JButton control to 
        // color the background manually. We want to control color.
        // First set everything to be the same color as parent background color...
        g.setColor(m_button.getParent().getBackground());
        g.fillRect(
            0,
            0,
            (int) buttonRect.getWidth(),
            (int) buttonRect.getHeight());

        if ((m_button.getModel().isPressed()) || (m_button.isSelected()))
        {
            // *** Paint the background when pressed or toggled.
            g.setColor(m_button.getBackground().darker());
            g.fillRoundRect(
                0,
                0,
                (int) buttonRect.getWidth() - 1,
                (int) buttonRect.getHeight() - 1,
                ARC_HEIGHT,
                ARC_WIDTH);
        }
        else if (m_button.getModel().isRollover())
        {
            // *** Paint the background when the mouse if over the button.
            g.setColor(new Color(251, 202, 106));
            g.fillRoundRect(
                0,
                0,
                (int) buttonRect.getWidth() - 1,
                (int) buttonRect.getHeight() - 1,
                ARC_HEIGHT,
                ARC_WIDTH);
            g.setColor(m_button.getBackground());
            g.fillRect(
                3,
                3,
                (int) buttonRect.getWidth() - 6,
                (int) buttonRect.getHeight() - 6);
        }
        else if ((m_button.isFocusPainted()) && (m_button.hasFocus()))
        {
            // *** Paint the background when the button has focus
            g.setColor(new Color(142, 175, 240));
            g.fillRoundRect(
                0,
                0,
                (int) buttonRect.getWidth() - 1,
                (int) buttonRect.getHeight() - 1,
                ARC_HEIGHT,
                ARC_WIDTH);
            g.setColor(m_button.getBackground());
            g.fillRect(
                3,
                3,
                (int) buttonRect.getWidth() - 6,
                (int) buttonRect.getHeight() - 6);
        }
        else
        {
            // *** Paint the background normally.
            g.setColor(m_button.getBackground());
            g.fillRoundRect(
                0,
                0,
                (int) buttonRect.getWidth() - 1,
                (int) buttonRect.getHeight() - 1,
                ARC_HEIGHT,
                ARC_WIDTH);
        }

    }

    protected void paintBorder(Graphics g)
    {
        Rectangle buttonRect = m_button.getBounds();

        if (!m_button.isEnabled())
        {
            g.setColor(new Color(201, 199, 186));
        }
        else
        {
            g.setColor(new Color(0, 60, 116));
        }

        g.drawRoundRect(
            0,
            0,
            (int) buttonRect.getWidth() - 1,
            (int) buttonRect.getHeight() - 1,
            ARC_HEIGHT,
            ARC_WIDTH);
    }

    protected void paintText(Graphics g)
    {
        ButtonModel model = m_button.getModel();
        FontMetrics fm = g.getFontMetrics();
        int mnemonicIndex = m_button.getDisplayedMnemonicIndex();
        Rectangle textRect = getTextRectangle();

        /* Draw the Text */
        if (model.isEnabled())
        {
            /*** paint the text normally */
            g.setColor(m_button.getForeground());
            BasicGraphicsUtils.drawStringUnderlineCharAt(
                g,
                m_button.getText(),
                mnemonicIndex,
                textRect.x + GetTextShiftOffset(),
                textRect.y + fm.getAscent() + GetTextShiftOffset());
        }
        else
        {
            /*** paint the text disabled ***/
            g.setColor(m_button.getBackground().brighter());
            BasicGraphicsUtils.drawStringUnderlineCharAt(
                g,
                m_button.getText(),
                mnemonicIndex,
                textRect.x,
                textRect.y + fm.getAscent());
            g.setColor(m_button.getBackground().darker());
            BasicGraphicsUtils.drawStringUnderlineCharAt(
                g,
                m_button.getText(),
                mnemonicIndex,
                textRect.x - 1,
                textRect.y + fm.getAscent() - 1);
        }
    }

    private int GetTextShiftOffset()
    {
        ButtonModel model = m_button.getModel();
        if ((model.isPressed()) || (m_button.isSelected()))
        {
            final String pp = "Button" + ".";
            return ((Integer) UIManager.get(pp + "textShiftOffset")).intValue();
        }
        else
        {
            return 0;
        }
    }

    /*
    * Returns the bounding rectangle for the component text.
    */
    private Rectangle getTextRectangle()
    {

        String text = m_button.getText();
        Icon icon =
            (m_button.isEnabled())
                ? m_button.getIcon()
                : m_button.getDisabledIcon();

        if ((icon == null) && (text == null))
        {
            return null;
        }

        Rectangle paintIconR = new Rectangle();
        Rectangle paintTextR = new Rectangle();
        Rectangle paintViewR = new Rectangle();
        Insets paintViewInsets = new Insets(0, 0, 0, 0);

        paintViewInsets = m_button.getInsets(paintViewInsets);
        paintViewR.x = paintViewInsets.left;
        paintViewR.y = paintViewInsets.top;
        paintViewR.width =
            m_button.getWidth()
                - (paintViewInsets.left + paintViewInsets.right);
        paintViewR.height =
            m_button.getHeight()
                - (paintViewInsets.top + paintViewInsets.bottom);

        Graphics g = m_button.getGraphics();
        if (g == null)
        {
            return null;
        }
        //String clippedText =
            SwingUtilities.layoutCompoundLabel(
                (JComponent) m_button,
                g.getFontMetrics(),
                text,
                icon,
                m_button.getVerticalAlignment(),
                m_button.getHorizontalAlignment(),
                m_button.getVerticalTextPosition(),
                m_button.getHorizontalTextPosition(),
                paintViewR,
                paintIconR,
                paintTextR,
                0);

        return paintTextR;
    }
}
