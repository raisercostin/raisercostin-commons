/*
 * Created on Nov 14, 2003
 */
package com.rp.gui;

import java.awt.Color;

import javax.swing.*;

/**
 * @author raiser
 */
public class JStatusBar extends JPanel
{
    JLabel label;
    public JStatusBar(String message)
    {
        label =new JLabel(message); 
        add(label);
    }

    public void setText(String message)
    {
        label.setText(message);
    }
    
    public void setForeground(Color fg)
    {
        if(label != null)
            label.setForeground(fg);
        super.setForeground(fg);
    }

}
