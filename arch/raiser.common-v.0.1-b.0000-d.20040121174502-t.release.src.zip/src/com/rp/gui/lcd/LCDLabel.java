/*
 * Created on Oct 23, 2003
 */
package com.rp.gui.lcd;

import java.awt.*;

import javax.swing.*;

import com.rp.gui.*;
import com.rp.gui.Console;

/**
 * @author raiser
 */
public class LCDLabel extends JLabel
{
    private LCDDigit lcdRender;
    private String value;

    public LCDLabel(String value)
    {
        lcdRender = new LCDDigit(2);
        this.value = null;
        setText(value);
    }
    public LCDLabel()
    {
        this(null);
    }
    public void paint(Graphics g)
    {
        super.paint(g);
        if (value != null)
        {
            float xAlign = 0.5f;
            if (getHorizontalAlignment() == RIGHT)
                xAlign = 1.0f;
            if (getHorizontalAlignment() == LEFT)
                xAlign = 0.0f;
            float yAlign = 0.5f;
            if (getHorizontalAlignment() == TOP)
                yAlign = 0.0f;
            if (getHorizontalAlignment() == BOTTOM)
                yAlign = 1.0f;

            lcdRender.draw(
                g,
                value,
                (int) ((getWidth() - getPreferredSize().getWidth()) * xAlign),
                (int) ((getHeight() - getPreferredSize().getHeight()) * yAlign
                    + getPreferredSize().getHeight()));
        }
    }
    public void setText(String value)
    {
        this.value = value;
        super.setText(null);
        if (lcdRender != null)
        {
            setPreferredSize(
                new Dimension(
                    lcdRender.getWidth(value),
                    lcdRender.getHeight(value)));
        }
    }
    public static void main(String[] args)
    {
        JLabel labelLeft = new LCDLabel("-01234.56789");
        JLabel labelRight = new LCDLabel("-01234.56789");
        JLabel labelCenter = new LCDLabel("-01234.56789");
        labelLeft.setAlignmentY(TOP_ALIGNMENT);
        labelRight.setAlignmentY(BOTTOM_ALIGNMENT);
        labelCenter.setAlignmentY(CENTER_ALIGNMENT);
        labelLeft.setBorder(BorderFactory.createLineBorder(Color.red));
        labelRight.setBorder(BorderFactory.createLineBorder(Color.red));
        labelCenter.setBorder(BorderFactory.createLineBorder(Color.red));
        JPanel panel = new JPanel(new GridLayout(4, 1));
        panel.add(labelLeft);
        JPanel panel2 = new JPanel(new AlignmentLayout());
        panel.add(panel2);
        panel2.add(labelRight, new AlignmentConstraints(AlignmentConstraints.RIGHT,AlignmentConstraints.BOTTOM));
        panel.add(labelCenter);
        Console.run(panel, 800, 600);
    }
}
