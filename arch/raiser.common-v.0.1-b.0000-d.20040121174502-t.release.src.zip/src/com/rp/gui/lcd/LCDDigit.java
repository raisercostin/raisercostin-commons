/*
 * Created on Oct 22, 2003
 */
package com.rp.gui.lcd;

import java.awt.Graphics;

import javax.swing.JPanel;

import com.rp.gui.Console;

/**
 * @author raiser
 */
public class LCDDigit
{
    private static final int LINES = 7;
    private static final int NORMAL_DIGIT_HEIGHT = 20;
    private static final int NORMAL_DIGIT_WIDTH = 8;
    private static final int NORMAL_POINT_WIDTH = 2;
    private static final int NORMAL_SPACE_WIDTH = 4;
    private int tickness;
    private int[][] xPoints = { { 2, 1, 6, 5 }, {
            2, 1, 6, 5 }, {
            2, 1, 6, 5 }, {
            0, 0, 1, 1 }, {
            6, 6, 7, 7 }, {
            0, 0, 1, 1 }, {
            6, 6, 7, 7 }
    };
    private int[][] yPoints = { { 1, 0, 0, 1 }, {
            9, 10, 10, 9 }, {
            18, 19, 19, 18 }, {
            1, 8, 7, 2 }, {
            2, 7, 8, 1 }, {
            11, 18, 17, 12 }, {
            12, 17, 18, 11 }
    };
    private int[][] xCorrect = { { 0, -1, 1, 1 }, {
            1, 0, 1, 0 }, {
            1, 0, 1, 0 }, {
            0, 0, 1, 1 }, {
            0, 0, 1, 1 }, {
            0, 0, 1, 1 }, {
            0, 0, 1, 1 }
    };
    private int[][] yCorrect = { { 0, 1, 1, 0 }, {
            1, 0, 0, 1 }, {
            1, 0, 0, 1 }, {
            1, -1, 0,0 }, {
            0, 0, -1, 1 }, {
            1, -1, 0, 0 }, {
            0, 0, -1, 1 }
    };
    private boolean[][] activation =
        { { true, false, true, true, true, true, true }, //0
        {
            false, false, false, false, true, false, true }, //1
        {
            true, true, true, true, false, false, true }, //2
        {
            true, true, true, false, true, false, true }, //3
        {
            false, true, false, false, true, true, true }, //4
        {
            true, true, true, false, true, true, false }, //5
        {
            true, true, true, true, true, true, false }, //6
        {
            false, false, true, false, true, false, true }, //7
        {
            true, true, true, true, true, true, true }, //8
        {
            true, true, true, false, true, true, true }, //9
        {
            false, true, false, false, false, false, false } //-
    };
    private int[] currentxs;
    private int[] currenties;
    public LCDDigit(int tickness)
    {
        this.tickness = tickness;
        currentxs = new int[4];
        currenties = new int[4];
    }
    public void draw(Graphics g, String digits, int x, int y)
    {
        for (int i = 0; i < digits.length(); i++)
        {
            draw(g, digits.charAt(i), x, y-1);
            x += getSpace(digits.charAt(i));
        }
    }
    private void draw(Graphics g, char c, int x, int y)
    {
        int index = getIndex(c);
        if(index == -1)
        {
            return;
        }
        if (index == 11)
        {
            g.fillRect(
                x,
                y - NORMAL_POINT_WIDTH * tickness / 2 + 1,
                NORMAL_POINT_WIDTH * tickness / 2,
                NORMAL_POINT_WIDTH * tickness / 2);
        }
        else
        {
            boolean[] actives = activation[index];
            for (int i = 0; i < LINES; i++)
            {
                if (actives[i])
                {
                    update(currentxs, currenties, x, y, i);
                    g.fillPolygon(currentxs, currenties, 4);
                }
            }
        }
    }
    private void update(int[] currentX, int[] currentY, int x, int y, int line)
    {
        for (int i = 0; i < currentX.length; i++)
        {
            currentX[i] =
                xPoints[line][i] * tickness / 2 + x + xCorrect[line][i];
            currentY[i] =
                -yPoints[line][i] * tickness / 2 + y + yCorrect[line][i];
        }
    }
    private int getIndex(char c)
    {
        if ((c >= '0') && (c <= '9'))
            return c - '0';
        if (c == '-')
            return 10;
        if (c == '.')
            return 11;
        return -1;
    }
    private int getSpace(char c)
    {
        if (((c >= '0') && (c <= '9')) || (c == '-'))
            return NORMAL_DIGIT_WIDTH * tickness / 2
                + NORMAL_SPACE_WIDTH * tickness / 2;
        if (c == '.')
            return NORMAL_POINT_WIDTH * tickness / 2
                + NORMAL_SPACE_WIDTH * tickness / 2;
        return 0;
    }
    public static void main(String[] args)
    {
        final LCDDigit lcdRender = new LCDDigit(2);
        JPanel panel = new JPanel()
        {
            public void paint(Graphics g)
            {
                lcdRender.draw(g, "-01234.56789", 100, 200);
            }
        };
        Console.run(panel, 800, 600);
    }
    public int getWidth(String value)
    {
        if(value == null)
            return 0;
        int sum = 0;
        for (int i = 0; i < value.length(); i++)
        {
            sum += getSpace(value.charAt(i));
        }
        return sum;
    }
    public int getHeight(String value)
    {
        if(value == null)
            return 0;
        return NORMAL_DIGIT_HEIGHT * tickness / 2;
    }
}
