/*
 * Created on Nov 9, 2003
 */
package com.rp.gui;
/*
 * 
 * Copyright(C) 1998 Tom Whittaker, SSEC, Univ of Wisconsin-Madison USA.
 * Developed under one or more grants from NASA, NSF and NOAA. You may use this
 * for any non-commercial applications. Not responsible for an consequences...
 *  
 */

import java.awt.*;
import java.awt.image.*;

/**
 * create an image with designated level transparent
 * 
 * @author Tom Whittaker, SSEC
 *  
 */

public class TransparentImage extends RGBImageFilter
{
    Image ti;
    private int transparent;

    /**
	 * create transparent image
	 * 
	 * @param parent
	 *            is the applet invoking this
	 * @param source
	 *            is the source image
	 * @param trans
	 *            is the color trans (rgb) to use as "transparent"
	 *  
	 */
    public TransparentImage(Image source, int trans)
    {

        canFilterIndexColorModel = true;
        transparent = trans;

        FilteredImageSource fis = new FilteredImageSource(source.getSource(), this);
        Component parent = null;
        ti = parent.createImage(fis);
        MediaTracker track = new MediaTracker(parent);
        track.addImage(ti, 0);
        try
        {
            track.waitForID(0);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
	 * return the transparent image
	 * 
	 * @return the Image with the prescripted level having alpha set to zero
	 *         (transparent)
	 *  
	 */
    public Image getImage()
    {
        return ti;
    }

    public int filterRGB(int x, int y, int rgb)
    {

        if ((rgb & 0x00ffffff) == transparent)
        {
            return (rgb & 0x00ffffff);

        }
        else
        {
            return rgb;
        }
    }
}
