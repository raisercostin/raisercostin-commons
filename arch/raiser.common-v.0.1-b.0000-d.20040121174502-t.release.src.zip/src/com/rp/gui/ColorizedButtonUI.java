/*
 * Created on Nov 24, 2003
 */
package com.rp.gui;
import java.awt.*;
import java.awt.image.*;

import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;
public class ColorizedButtonUI extends BasicButtonUI
{
    private static ColorizeImageFilter imageFilter = new ColorizeImageFilter();

    public void paint(Graphics g, JComponent c)
    {
        boolean opaque = c.isOpaque();
        if (opaque)
        { // Fill background      
            g.setColor(c.getBackground());
            g.fillRect(0, 0, c.getWidth(), c.getHeight());
        } // Let the UI paint to offscreen image  
        c.setOpaque(false);
        Image img =
            new BufferedImage(
                c.getWidth(),
                c.getHeight(),
                BufferedImage.TYPE_INT_ARGB);
        Graphics g2 = img.getGraphics();
        g2.setFont(g.getFont());

        //JButton.paintComponent(g2);
        //c.paint(g2);

        // Colorize!    
        img = imageFilter.colorize(c, img, c.getBackground());
        // Paint offscreen image to button  
        g.drawImage(img, 0, 0, null);
        c.setOpaque(opaque);
    }

    public static Graphics createSwingGraphics(Graphics g)
    {
        if (g == null)
        {
            Thread.dumpStack();
            return null;
        }
        return g.create();
    }

    private static class ColorizeImageFilter extends RGBImageFilter
    {
        double cr, cg, cb;
        int bgRGB, fgRGB;
        public ColorizeImageFilter()
        {
            canFilterIndexColorModel = true;
        }
        public Image colorize(JComponent comp, Image fromImage, Color c)
        {
            cr = c.getRed() / 255.0;
            cg = c.getGreen() / 255.0;
            cb = c.getBlue() / 255.0;
            bgRGB = comp.getBackground().getRGB();
            fgRGB = comp.getForeground().getRGB();
            ImageProducer producer =
                new FilteredImageSource(fromImage.getSource(), this);
            return new ImageIcon(comp.createImage(producer)).getImage();
        }
        public int filterRGB(int x, int y, int rgb)
        {
            int alpha = rgb & 0xff000000;
            if (rgb == bgRGB || rgb == fgRGB || alpha < 0x80000000)
            {
                return rgb;
            } // Assume all rgb values are shades of gray     
            double grayLevel = 2 * (rgb & 0xff) / 255.0;
            double r, g, b;
            if (grayLevel <= 1.0)
            {
                r = cr * grayLevel;
                g = cg * grayLevel;
                b = cb * grayLevel;
            }
            else
            {
                grayLevel -= 1.0;
                r = cr + (1.0 - cr) * grayLevel;
                g = cg + (1.0 - cg) * grayLevel;
                b = cb + (1.0 - cb) * grayLevel;
            }
            return (
                alpha
                    + (((int) (r * 255)) << 16)
                    + (((int) (g * 255)) << 8)
                    + (int) (b * 255));
        }
    }
}