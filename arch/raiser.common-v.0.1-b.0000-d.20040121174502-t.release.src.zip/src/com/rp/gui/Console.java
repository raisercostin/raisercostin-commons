package com.rp.gui;

import java.awt.event.*;

import javax.swing.*;

public class Console
{
    // Create a title string from the class name:
    public static String title(Object o)
    {
        String t = o.getClass().toString();
        // Remove the word "class":
        if (t.indexOf("class") != -1)
            t = t.substring(6);
        return t;
    }
    public static Thread run(
        JFrame frame,
        int left,
        int top,
        int width,
        int height)
    {
        Thread result = setupClosing(frame); 
        frame.setLocation(left, top);
        frame.setSize(width, height);
        frame.setVisible(true);
        return result;
    }
    public static Thread run(
        JApplet applet,
        int left,
        int top,
        int width,
        int height)
    {
        JFrame frame = new JFrame(title(applet));
        Thread result = setupClosing(frame); 
        frame.getContentPane().add(applet);
        frame.setLocation(left, top);
        frame.setSize(width, height);
        applet.init();
        applet.start();
        frame.setVisible(true);
        return result;
    }
    public static Thread run(
        JPanel panel,
        int left,
        int top,
        int width,
        int height)
    {
        JFrame frame = new JFrame(title(panel));
        Thread result = setupClosing(frame); 
        frame.getContentPane().add(panel);
        frame.setLocation(left, top);
        frame.setSize(width, height);
        frame.setVisible(true);
        return result;
    }
    public static Thread run(String title, JPanel panel)
    {
        int width = (int) panel.getPreferredSize().getWidth();
        int height = (int) panel.getPreferredSize().getHeight();
        JFrame frame = new JFrame(title);
        Thread result = setupClosing(frame); 
        frame.getContentPane().add(panel);
        int maxWidth =
            (int) frame.getGraphicsConfiguration().getBounds().getWidth();
        int maxHeight =
            (int) frame.getGraphicsConfiguration().getBounds().getHeight();
        if (panel instanceof Menuable)
        {
            frame.setJMenuBar(((Menuable) panel).getMenuBar());
        }
        frame.setSize(width, height);
        frame.setLocation((maxWidth - width) / 2, (maxHeight - height) / 2);
        frame.setVisible(true);
        return result;
    }
    public static Thread run(JPanel panel)
    {
        return run(
            panel,
            (int) panel.getPreferredSize().getWidth(),
            (int) panel.getPreferredSize().getHeight());
    }
    public static Thread run(JPanel panel, int width, int height)
    {
        final JFrame frame = new JFrame(title(panel));
        Thread result = setupClosing(frame); 
        frame.getContentPane().add(panel);
        int maxWidth =
            (int) frame.getGraphicsConfiguration().getBounds().getWidth();
        int maxHeight =
            (int) frame.getGraphicsConfiguration().getBounds().getHeight();
        frame.setSize(width, height);
        frame.setLocation((maxWidth - width) / 2, (maxHeight - height) / 2);
        frame.setVisible(true);
        return result;
    }
    private static Thread setupClosing(final JFrame frame)
    {
        final Thread aThread = new Thread()
        {
            public void run()
            {
                try
                {
                    synchronized (this)
                    {
                        wait();
                    }
                }
                catch (InterruptedException e)
                {
                    //e.printStackTrace();
                }
            }
        
        };
        aThread.start();
        frame.addWindowListener(new WindowAdapter()
        {
            
            /* (non-Javadoc)
             * @see java.awt.event.WindowAdapter#windowClosing(java.awt.event.WindowEvent)
             */
            public void windowClosing(WindowEvent e)
            {
                frame.dispose();
                super.windowClosing(e);
                aThread.interrupt();
            }
        });
        return aThread;
    }
}