/*
 * Created on Nov 7, 2003
 */
package com.rp.gui;

import javax.swing.*;
import javax.swing.JTextArea;
import javax.swing.text.Document;

/**
 * @author raiser
 */
public class JWrappedLabel extends JTextArea
{

    /**
	 *  
	 */
    public JWrappedLabel()
    {
        super();
    }

    /**
	 * @param rows
	 * @param columns
	 */
    public JWrappedLabel(int rows, int columns)
    {
        super(rows, columns);
    }

    /**
	 * @param text
	 */
    public JWrappedLabel(String text)
    {
        super(text);
    }

    /**
	 * @param text
	 * @param rows
	 * @param columns
	 */
    public JWrappedLabel(String text, int rows, int columns)
    {
        super(text, rows, columns);
    }

    /**
	 * @param doc
	 */
    public JWrappedLabel(Document doc)
    {
        super(doc);
    }

    /**
	 * @param doc
	 * @param text
	 * @param rows
	 * @param columns
	 */
    public JWrappedLabel(Document doc, String text, int rows, int columns)
    {
        super(doc, text, rows, columns);
    }
    /* (non-Javadoc)
     * @see javax.swing.text.JTextComponent#setText(java.lang.String)
     */
    public void setText(String t)
    {
        super.setText(t);
        setRows(1);
    }
    public void updateUI()
    {
        super.updateUI();

        // turn on wrapping and disable editing and highlighting

        setLineWrap(true);
        setWrapStyleWord(true);
        setHighlighter(null);
        setEditable(false);
        setRows(getRows());

        // Set the text area's border, colors and font to
        // that of a label

        LookAndFeel.installBorder(this, "Label.border");

        LookAndFeel.installColorsAndFont(
            this,
            "Label.background",
            "Label.foreground",
            "Label.font");
    }
}
